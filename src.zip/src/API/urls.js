
export const BASE_URL = "http://jsonplaceholder.typicode.com";


const USER = "/user";
export const LOGIN = BASE_URL + USER + "/login";

// photos
export const GET_ALL_PHOTOS = BASE_URL + "/photos";
